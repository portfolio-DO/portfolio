"""
ustna.pl Scraper + Groq Deduplication
Pobiera pytania z ustna.pl i deduplikuje je przez Groq API.

Wymagania:
    pip install playwright python-dotenv requests
    playwright install chromium
"""

import asyncio
import json
import os
import re
import sys
from datetime import datetime, timedelta
from pathlib import Path

import requests
from playwright.async_api import async_playwright

# ─── CONFIG ────────────────────────────────────────────────────────────────────
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GROQ_MODEL   = "llama-3.1-70b-versatile"
BASE_URL     = "https://ustna.pl"
OUTPUT_DIR   = Path(__file__).parent / "data"

GROQ_SYSTEM_PROMPT = """Jesteś ekspertem od analizy i grupowania pytań egzaminacyjnych z polskich studiów medycznych.

Otrzymasz listę pytań egzaminacyjnych w formacie JSON. Twoim zadaniem jest:

1. GRUPOWANIE: Pogrupuj pytania o tym samym lub bardzo podobnym znaczeniu (nawet jeśli są inaczej sformułowane, skrócone, zawierają błędy ortograficzne, lub mają inną kolejność słów).

2. KANONIZACJA: Dla każdej grupy wybierz jedno "kanoniczne" pytanie — najbardziej kompletne, poprawne gramatycznie i precyzyjne.

3. ZWRÓĆ WYNIK jako JSON w dokładnie tym formacie (bez żadnego dodatkowego tekstu, tylko czysty JSON):
{
  "groups": [
    {
      "canonical": "Pełne, kanoniczne pytanie",
      "count": 3,
      "ids": [0, 5, 12],
      "variants": ["wariant 1", "wariant 2", "wariant 3"]
    }
  ]
}

ZASADY GRUPOWANIA:
- To samo pytanie kliniczne z różnymi skrótami → jedna grupa (np. "OZW" i "ostry zespół wieńcowy")
- To samo pytanie z różną kolejnością słów → jedna grupa
- Pytania z błędami literowymi ale tym samym znaczeniu → jedna grupa
- Pytania o RÓŻNYCH chorobach/mechanizmach → OSOBNE grupy, nawet jeśli brzmią podobnie
- Zachowaj polskie znaki diakrytyczne w kanonicznym pytaniu
- Nie grupuj pytań tylko dlatego, że dotyczą tej samej dziedziny (np. kardiologii) — muszą pytać o to samo

Odpowiedz WYŁĄCZNIE JSONem, bez markdown, bez wyjaśnień."""

# ─── SCRAPER ───────────────────────────────────────────────────────────────────

async def scrape_date(page, date_str: str) -> list[dict]:
    """Scrape questions for a specific date from ustna.pl."""
    url = f"{BASE_URL}/?data={date_str}" if date_str else BASE_URL
    print(f"  📅 Scrapuję: {url}")

    try:
        await page.goto(url, wait_until="networkidle", timeout=30000)
    except Exception as e:
        print(f"  ⚠️  Timeout/błąd dla {url}: {e}")
        return []

    # Expand all "Zobacz więcej" buttons
    expanded = 0
    while True:
        buttons = await page.query_selector_all(
            'button:has-text("Zobacz więcej"), '
            'a:has-text("Zobacz więcej"), '
            '[data-action="expand"], '
            '.load-more, '
            'button.btn-load-more'
        )
        if not buttons:
            break
        clicked = 0
        for btn in buttons:
            try:
                if await btn.is_visible():
                    await btn.click()
                    await page.wait_for_timeout(500)
                    clicked += 1
                    expanded += 1
            except Exception:
                pass
        if clicked == 0:
            break
    if expanded:
        print(f"  🔽 Rozwinięto {expanded} sekcji 'Zobacz więcej'")
        await page.wait_for_timeout(1000)

    questions = await page.evaluate("""() => {
        const results = [];
        
        // Strategy 1: Look for question cards / entries with timestamps
        const selectors = [
            '.question-entry',
            '.pytanie',
            '.question-card',
            '.entry',
            '[class*="question"]',
            '[class*="pytanie"]',
            'article',
            '.card',
        ];
        
        let items = [];
        for (const sel of selectors) {
            const found = document.querySelectorAll(sel);
            if (found.length > 2) {
                items = Array.from(found);
                break;
            }
        }
        
        // Strategy 2: Find by time patterns (HH:MM)
        if (items.length === 0) {
            const timeRegex = /^\\d{1,2}:\\d{2}$/;
            const allElements = document.querySelectorAll('*');
            const timeElements = [];
            for (const el of allElements) {
                const text = el.textContent.trim();
                if (timeRegex.test(text) && el.children.length === 0) {
                    timeElements.push(el);
                }
            }
            
            for (const timeEl of timeElements) {
                const parent = timeEl.closest('div, li, article, section') || timeEl.parentElement;
                if (parent && !items.includes(parent)) {
                    items.push(parent);
                }
            }
        }
        
        // Strategy 3: Parse the whole page structure
        if (items.length === 0) {
            // Look for list items or divs that contain question-like text
            const candidates = document.querySelectorAll('li, .row > div, main div > div');
            for (const el of candidates) {
                const text = el.textContent.trim();
                if (text.length > 20 && text.length < 2000) {
                    items.push(el);
                }
            }
        }
        
        const timeRegex = /\\b(\\d{1,2}:\\d{2})\\b/;
        const seenTexts = new Set();
        
        for (const item of items) {
            const rawText = item.textContent.trim();
            
            // Skip too short or too long
            if (rawText.length < 15 || rawText.length > 3000) continue;
            
            // Extract time
            const timeMatch = rawText.match(timeRegex);
            const time = timeMatch ? timeMatch[1] : null;
            
            // Get the main question text (try to remove metadata)
            let questionText = rawText;
            
            // Try to get cleaner text from specific child elements
            const textEls = item.querySelectorAll('p, span.text, .content, .body, .question-text');
            if (textEls.length > 0) {
                questionText = Array.from(textEls).map(e => e.textContent.trim()).join(' ').trim();
            }
            
            // Clean up
            questionText = questionText
                .replace(/\\s+/g, ' ')
                .replace(/^\\d{1,2}:\\d{2}\\s*/, '')
                .trim();
            
            if (questionText.length < 10) continue;
            
            // Dedup by text
            const key = questionText.substring(0, 100);
            if (seenTexts.has(key)) continue;
            seenTexts.add(key);
            
            // Try to find author
            const authorEl = item.querySelector('[class*="autor"], [class*="author"], [class*="user"], .nick');
            const author = authorEl ? authorEl.textContent.trim() : null;
            
            results.push({
                text: questionText,
                time: time,
                author: author,
                html_preview: item.innerHTML.substring(0, 200),
            });
        }
        
        return results;
    }""")

    # Fallback: try to scrape with more aggressive approach
    if not questions:
        print("  🔄 Próba alternatywnego scrapowania...")
        questions = await aggressive_scrape(page)

    # Add date to each question
    for q in questions:
        q["date"] = date_str
        q["scraped_at"] = datetime.now().isoformat()

    print(f"  ✅ Znaleziono {len(questions)} pytań")
    return questions


async def aggressive_scrape(page) -> list[dict]:
    """More aggressive scraping - tries multiple strategies."""
    return await page.evaluate("""() => {
        const results = [];
        const seen = new Set();
        
        // Get all text nodes that look like questions
        const walker = document.createTreeWalker(
            document.body,
            NodeFilter.SHOW_TEXT,
            null
        );
        
        const textNodes = [];
        let node;
        while ((node = walker.nextNode())) {
            const text = node.textContent.trim();
            if (text.length > 30 && text.length < 1000 && text.includes(' ')) {
                textNodes.push({ node, text });
            }
        }
        
        // Group by proximity - texts near time elements are likely questions
        const timeRegex = /\\b\\d{1,2}:\\d{2}\\b/;
        
        for (const { node, text } of textNodes) {
            if (seen.has(text)) continue;
            
            // Skip navigation, meta, script content
            const parent = node.parentElement;
            if (!parent) continue;
            const tag = parent.tagName.toLowerCase();
            if (['script', 'style', 'meta', 'link', 'head', 'nav', 'footer'].includes(tag)) continue;
            
            // Check if this looks like a medical/exam question
            const medicalKeywords = ['jakie', 'które', 'co to', 'wymień', 'opisz', 'jak', 'dlaczego', 
                                      'czym', 'kiedy', 'gdzie', 'objawy', 'leczenie', 'rozpoznanie',
                                      'mechanizm', 'przyczyny', 'powikłania', 'diagnostyka', '?'];
            const looksLikeQuestion = medicalKeywords.some(kw => text.toLowerCase().includes(kw));
            
            if (looksLikeQuestion || text.endsWith('?')) {
                seen.add(text);
                
                // Look for time nearby
                const container = parent.closest('div, li, article, section') || parent;
                const containerText = container.textContent;
                const timeMatch = containerText.match(/\\b(\\d{1,2}:\\d{2})\\b/);
                
                results.push({
                    text: text.replace(/\\s+/g, ' ').trim(),
                    time: timeMatch ? timeMatch[1] : null,
                    author: null,
                });
            }
        }
        
        return results;
    }""")


async def scrape_multiple_dates(days: int = 7) -> list[dict]:
    """Scrape questions from the last N days."""
    all_questions = []
    dates = [(datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days)]

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36",
            viewport={"width": 1280, "height": 900},
        )
        page = await context.new_page()

        # First visit to accept cookies etc.
        print(f"🌐 Łączę z {BASE_URL}...")
        try:
            await page.goto(BASE_URL, wait_until="networkidle", timeout=20000)
            await page.wait_for_timeout(2000)
            # Try to dismiss cookie banner
            for selector in ['button:has-text("Akceptuj")', 'button:has-text("OK")', '#accept-cookies', '.cookie-accept']:
                try:
                    btn = await page.query_selector(selector)
                    if btn:
                        await btn.click()
                        await page.wait_for_timeout(500)
                        break
                except Exception:
                    pass
        except Exception as e:
            print(f"⚠️  Błąd przy pierwszym wejściu: {e}")

        for date_str in dates:
            questions = await scrape_date(page, date_str)
            all_questions.extend(questions)
            await asyncio.sleep(1.5)  # polite delay

        await browser.close()

    print(f"\n📊 Łącznie zebrano: {len(all_questions)} pytań z {days} dni")
    return all_questions


# ─── GROQ DEDUPLICATION ────────────────────────────────────────────────────────

def groq_deduplicate(questions: list[dict]) -> dict:
    """Send questions to Groq for intelligent deduplication."""
    if not GROQ_API_KEY:
        print("⚠️  Brak GROQ_API_KEY — pomijam deduplikację")
        return {"groups": []}

    print(f"\n🤖 Wysyłam {len(questions)} pytań do Groq ({GROQ_MODEL})...")

    # Prepare input - send in batches if too many
    BATCH_SIZE = 80
    all_groups = []
    global_offset = 0

    for batch_start in range(0, len(questions), BATCH_SIZE):
        batch = questions[batch_start : batch_start + BATCH_SIZE]
        print(f"  📦 Batch {batch_start//BATCH_SIZE + 1}: pytania {batch_start}–{batch_start+len(batch)-1}")

        input_data = [
            {"id": batch_start + i, "text": q["text"], "date": q.get("date", ""), "time": q.get("time", "")}
            for i, q in enumerate(batch)
        ]

        user_message = f"""Pogrupuj poniższe {len(input_data)} pytań egzaminacyjnych według znaczenia:

{json.dumps(input_data, ensure_ascii=False, indent=2)}

Pamiętaj: odpowiedz WYŁĄCZNIE czystym JSONem w podanym formacie."""

        try:
            response = requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": GROQ_MODEL,
                    "messages": [
                        {"role": "system", "content": GROQ_SYSTEM_PROMPT},
                        {"role": "user", "content": user_message},
                    ],
                    "temperature": 0.1,
                    "max_tokens": 8000,
                },
                timeout=90,
            )
            response.raise_for_status()
            raw = response.json()["choices"][0]["message"]["content"].strip()

            # Clean up potential markdown fences
            raw = re.sub(r"^```json\s*", "", raw)
            raw = re.sub(r"```\s*$", "", raw)
            raw = raw.strip()

            parsed = json.loads(raw)
            batch_groups = parsed.get("groups", [])

            # Map local IDs back to global IDs
            for group in batch_groups:
                group["ids"] = [batch_start + local_id for local_id in group.get("ids", [])]

            all_groups.extend(batch_groups)
            print(f"  ✅ Groq zwrócił {len(batch_groups)} grup")

        except requests.HTTPError as e:
            print(f"  ❌ Błąd HTTP Groq: {e.response.status_code} — {e.response.text[:200]}")
        except json.JSONDecodeError as e:
            print(f"  ❌ Błąd parsowania JSON z Groq: {e}")
            print(f"  Raw response: {raw[:500]}")
        except Exception as e:
            print(f"  ❌ Nieoczekiwany błąd: {e}")

    # Sort groups by count descending
    all_groups.sort(key=lambda g: g.get("count", 1), reverse=True)
    return {"groups": all_groups}


# ─── MAIN ──────────────────────────────────────────────────────────────────────

def save_output(questions: list[dict], dedup: dict):
    """Save raw questions and deduplicated data to JSON files."""
    OUTPUT_DIR.mkdir(exist_ok=True)

    # Raw questions
    raw_path = OUTPUT_DIR / "questions_raw.json"
    with open(raw_path, "w", encoding="utf-8") as f:
        json.dump(questions, f, ensure_ascii=False, indent=2)
    print(f"\n💾 Surowe pytania → {raw_path}")

    # Deduplicated
    dedup_path = OUTPUT_DIR / "questions_dedup.json"
    with open(dedup_path, "w", encoding="utf-8") as f:
        json.dump(dedup, f, ensure_ascii=False, indent=2)
    print(f"💾 Deduplikacja    → {dedup_path}")

    # Combined output for frontend
    combined = {
        "scraped_at": datetime.now().isoformat(),
        "total_raw": len(questions),
        "total_groups": len(dedup.get("groups", [])),
        "questions": questions,
        "deduplication": dedup,
    }
    combined_path = OUTPUT_DIR / "questions.json"
    with open(combined_path, "w", encoding="utf-8") as f:
        json.dump(combined, f, ensure_ascii=False, indent=2)
    print(f"💾 Plik główny     → {combined_path}")
    return combined_path


async def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 7
    print(f"🚀 ustna.pl Scraper — ostatnie {days} dni\n{'='*50}")

    # 1. Scrape
    questions = await scrape_multiple_dates(days)

    if not questions:
        print("\n❌ Nie udało się pobrać żadnych pytań.")
        print("   Możliwe przyczyny:")
        print("   - Strona zmieniła strukturę HTML")
        print("   - Brak dostępu do internetu")
        print("   - ustna.pl wymaga logowania")
        sys.exit(1)

    # 2. Deduplicate via Groq
    dedup_result = groq_deduplicate(questions)

    # 3. Save
    output_path = save_output(questions, dedup_result)

    print(f"\n✨ Gotowe!")
    print(f"   📊 Pytań surowych: {len(questions)}")
    print(f"   🎯 Unikalnych grup: {len(dedup_result.get('groups', []))}")
    print(f"   📁 Otwórz index.html i załaduj: {output_path}")


if __name__ == "__main__":
    asyncio.run(main())
